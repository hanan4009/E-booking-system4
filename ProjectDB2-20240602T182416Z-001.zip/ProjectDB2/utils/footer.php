<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>S</strong><span class = "small footerSubtext">ukkur IBA</span>
                        <strong>U</strong><span class = "small footerSubtext">niversity</span>
                        <strong>M</strong><span class = "small footerSubtext">irpurkhas</span>
                        <strong>C</strong><span class = "small footerSubtext">ampus</span>
                    </p>

                    <p class = "footerSubtext2">
                       Sukkur IBA Mirpurkhas Campus Khipro Road , Mirpurkhas-69230
                        &copy; Our Events Venue & Catering 2024.
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    The final database project done by<br>
                    Creative Computing Sajjad Ahmed.<br>
                    Backend: Bhushan Nandani.
                    Hanan: Farig Manhu.
                    Hyder: Safa masat
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                        <img src = "images/facebook.png">
                        <img src = "images/twitter.png">
                        <img src = "images/googleplus.png">
                        <img src = "images/youtube.png">
                </div>
            </section>
        </div>
    </div>
</footer>