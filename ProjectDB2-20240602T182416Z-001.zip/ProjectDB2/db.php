<?php
$con = mysqli_connect("localhost","root","","hotel_db") or die(mysql_error());

?>