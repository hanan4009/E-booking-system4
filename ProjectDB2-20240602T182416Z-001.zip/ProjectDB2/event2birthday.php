<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('utils/styles.php'); ?>
</head>
<body id="page-top">
    <?php
    session_start();
    include('utils/header.php');
    include('admin/db_connect.php');

    $query = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
    foreach ($query as $key => $value) {
        if(!is_numeric($key))
            $_SESSION['setting_'.$key] = $value;
    }
    ?>

    <!-- Main Body of Dynamic webpages... -->
    <div id="page-content">
        <?php 
        $page = isset($_GET['page']) ? $_GET['page'] : "homebirthday";
        include $page.'.php';
        ?>
    </div>

    <?php include('utils/footer.php'); ?>
    
    <?php $conn->close(); ?>
</body>
</html>
