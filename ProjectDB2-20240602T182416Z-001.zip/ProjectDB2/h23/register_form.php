<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Registration Form</title>
    <?php require 'utils/styles.php'; ?>
    <?php require 'utils/scripts.php'; ?>
     <!-- Include Bootstrap CSS -->
</head>
<body>
    <?php require 'utils/header.php'; ?>
    <div class="content">
        <div class="container">
            <div class="col-md-6 col-md-offset-3">
                <form  id="registrationForm" action = "register.php" class="form-group" method="POST">
                    <!-- Existing form elements -->
                    <!-- Add new fields for registration -->
                    <div class="form-group">
                        <label for="fname">First Name: </label>
                        <input type="text" id="fname" name="fname" class="form-control" 
                        value="<?php if (isset($fname)) echo $fname; ?>"
                        >
                    <span class="error">
                    <?php if (isset($errors['fname'])) echo $errors['fname']; ?>
                    </span>
                    </div>
                    <div class="form-group">
                        <label for="lname">Last Name: </label>
                        <input type="text" id="lname" name="lname" class="form-control" 
                        value="<?php if (isset($lname)) echo $lname; ?>"
                        >
                    <span class="error">
                    <?php if (isset($errors['lname'])) echo $errors['lname']; ?>
                    </span>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender: </label>
                        <select id="gender" name="gender"  class="form-control" value="<?php if (isset($gender)) echo $gender; ?>"
                        >
                    <span class="error">
                    <?php if (isset($errors['gender'])) echo $errors['gender']; ?>
                    </span>>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="email">Email: </label>
                        <input type="email" id="email" name="email" class="form-control" 
                            value="<?php if (isset($email)) echo $email; ?>"
                                   >
                            <span class="error">
                                <?php if (isset($errors['email'])) echo $errors['email']; ?>
                            </span>
                    </div>
                    
                    <div class="form-group">
                            <label for="username">Username: </label>
                            <input type="text"
                                   id="username"
                                   name="username"
                                   class="form-control"
                                   value="<?php if (isset($username)) echo $username; ?>">
                                <span class="error">
                                    <?php if (isset($errors['username'])) echo $errors['username']; ?>
                                </span>
                        </div>
                        <div class="form-group">
                            <label for="password">Password: </label>
                            <input type="password"
                                   id="password"
                                   name="password"
                                   class="form-control" 
                                   value="<?php if (isset($password)) echo $password; ?>">
                            <span class="error">
                                <?php if (isset($errors['password'])) echo $errors['password']; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="cpassword">Confirm Password: </label>
                            <input type="password"
                                   id="cpassword"
                                   name="cpassword"
                                   class="form-control" 
                                   value="<?php if (isset($cpassword)) echo $cpassword; ?>"
                        >
                    <span class="error">
                    <?php if (isset($errors['cpassword'])) echo $errors['cpassword']; ?>
                    </span>
                        </div>
                    <!-- End of new fields -->
                    <button type="submit" onclick="submitForm()"  class="btn btn-default">Register</button>
                    <div class="form-group">
                     <a href="forgot_password.php">Forgot Password?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
function submitForm() {
    var form = document.getElementById('registrationForm');
    var formData = new FormData(form);

    // First action: register.php
    var xhrRegister = new XMLHttpRequest();
    xhrRegister.open('POST', 'register.php', true);
    xhrRegister.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhrRegister.onreadystatechange = function () {
        if (xhrRegister.readyState === XMLHttpRequest.DONE) {
            if (xhrRegister.status === 200) {
                console.log(xhrRegister.responseText);
                alert('Registration successful!');
                // Handle response from register.php if needed
            } else {
            // Handle error message
            console.error('Error:', xhrRegister.statusText);
            alert('Registration failed. Please try again.');
            }
        }
    };
    xhrRegister.send(formData);

    // Second action: register1.php
    var xhrRegister1 = new XMLHttpRequest();
    xhrRegister1.open('POST', 'register1.php', true);
    xhrRegister1.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhrRegister1.onreadystatechange = function () {
        if (xhrRegister1.readyState === XMLHttpRequest.DONE) {
            if (xhrRegister1.status === 200) {
                // Handle response from register1.php if needed
                console.log(xhrRegister1.responseText);
            } else {
                console.error('Error:', xhrRegister1.statusText);
            }
        }
    };
    xhrRegister1.send(formData);
}
</script>

    <?php require 'utils/footer.php'; ?>
</body>
</html>
