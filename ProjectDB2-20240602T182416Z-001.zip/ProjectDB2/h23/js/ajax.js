document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registrationForm');
    const usernameInput = document.getElementById('username');
    const usernameError = document.getElementById('usernameError');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        const username = usernameInput.value.trim();

        // Validate other form fields if needed
        if (username === '') {
            usernameError.textContent = 'Username will be required';
            return;
        }
        if (username !== '') {
            // Send AJAX request to check username availability
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'check_username.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.available) {
                            usernameError.textContent = 'Username available'; // Username available
                        } else {
                            usernameError.textContent = 'Username is not available'; // Username already taken
                        }
                    } else {
                        console.error('Error:', xhr.statusText);
                    }
                }
            };
            xhr.send('username=' + encodeURIComponent(username));
        } else {
            usernameError.textContent = ''; // Clear error message if username is empty
        }

        // Perform final validation or AJAX submission if everything is okay
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'wrold.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Handle successful registration or display errors
                    console.log(xhr.responseText);
                } else {
                    console.error('Error:', xhr.statusText);
                }
            }
        };
        xhr.send(new FormData(form)); // Send form data to register1.php
    });
});
