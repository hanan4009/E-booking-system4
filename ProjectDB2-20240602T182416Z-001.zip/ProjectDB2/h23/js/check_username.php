<?php
require_once 'classes/UserTable1.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])){
    $username = $_POST['username'];
    $userTable = new UserTable1(DB::getConnection());
    $user = $userTable->getUserByUsername($username);

    if ($user != null) {
        $response['available'] = false;
    } else {
        $response['available'] = true;
    }
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Invalid request
    http_response_code(400);
    echo json_encode(array('error' => 'Invalid request'));
}
?>