<?php
require_once 'utils/functions.php';
require_once 'classes/User1.php';
require_once 'classes/DB.php';
require_once 'classes/UserTable1.php';
?>
<?php
// try to register the user - if there are any error/
// exception, catch it and send the user back to the
// login form with an error message
try {
    $formdata = array();
    $errors = array();
    
    $input_method = INPUT_POST;
    $formdata['fname'] = filter_input($input_method, "fname", FILTER_SANITIZE_STRING);
    $formdata['lname'] = filter_input($input_method, "lname", FILTER_SANITIZE_STRING);
    $formdata['gender'] = filter_input($input_method, "gender", FILTER_SANITIZE_STRING);

    $formdata['username'] = filter_input($input_method, "username", FILTER_SANITIZE_STRING);
    $formdata['password'] = filter_input($input_method, "password", FILTER_SANITIZE_STRING);
    $formdata['cpassword'] = filter_input($input_method, "cpassword", FILTER_SANITIZE_STRING);

    $formdata['email'] = filter_input($input_method, "email", FILTER_SANITIZE_STRING);


    if (empty($formdata['fname'])) {
        $errors['fname'] = "First name is required";
    }

    if (empty($formdata['lname'])) {
        $errors['lname'] = "Last name is required";
    }
    // throw an exception if any of the form fields 
    // are empty
    if (empty($formdata['username'])) {
        $errors['username'] = "Username required";
    }
    if (empty($formdata['email'])) {
        $errors['email'] = "email required";
    }
  //  $email = filter_var($formdata['username'], FILTER_VALIDATE_EMAIL);
   // if ($email != $formdata['username']) {
    //    $errors['username'] = "Valid email required required";
   // }
  // if (empty($formdata['email'])) {
  //  $errors['email'] = "Email required";
//}


    if (empty($formdata['password'])) {
        $errors['password'] = "Password required";
    }
    if (empty($formdata['cpassword'])) {
        $errors['cpassword'] = "Confirm password required";
    }
    // if the password fields do not match 
    // then throw an exception
    if (!empty($formdata['password']) && !empty($formdata['cpassword']) 
            && $formdata['password'] != $formdata['cpassword']) {
        $errors['password'] = "Passwords must match";
    }

    if (empty($errors)) {
        // since none of the form fields were empty, 
        // store the form data in variables
        $username = $formdata['username'];
        $password = $formdata['password'];
        $email = $formdata['email'];
        $fname = $formdata['fname'];
        $lname = $formdata['lname'];
        $gender = $formdata['gender'];

        // create a UserTable object and use it to retrieve 
        // the users
        $connection = DB::getConnection();
        $userTable = new UserTable1($connection);
        $user = $userTable->getUserByUsername($username);

        // since password fields match, see if the username
        // has already been registered - if it is then throw
        // and exception
        if ($user != null) {
            $errors['username'] = "Username already registered , Kindly wait for approval, or contact administrator";
        }
        if($userTable->emailExists($email))
        {
            $errors['email'] = "Email already registered Kindly wait for approval, or contact administrator";
        }
    }
    
    if (!empty($errors)) {
        throw new Exception("There were errors. Please fix them.");
    }
    
    // since the username is not aleady registered, create
    // a new User object, add it to the database using the
    // UserTable object, and store it in the session array
    // using the key 'user'
    $user = new User1(null, $username, $password, $email, $fname, $lname, $gender, "user");
    $id = $userTable->insert($user);
    $user->setId($id);
    $_SESSION['user'] = $user;
    
    // now the user is registered and logged in so redirect
    // them the their home page
    // Note the user is redirected to home.php rather than
    // requiring the home.php script at this point - this 
    // ensures that if the user refreshes the home page they
    // will not be resubmitting the login form.
    // 
    // require 'home.php';
 //   header('Location: index.php');
}
catch (Exception $ex) {
    // if an exception occurs then extract the message
    // from the exception and send the user the
    // registration form
    $errorMessage = $ex->getMessage();
    $message = $errorMessage;
    echo "<script>alert('$message');</script>";
    require 'register_form.php';
}
?>
