<?php

require_once 'User1.php';

class UserTable1 {
    private $link;
        
        public function __construct($connection) {
            $this->link = $connection;
        }
    
        public function insert($user) {
            if (!isset($user)) {
                throw new Exception("User required");
            }
    
            // Check if the email already exists (if needed)
            if ($this->emailExists($user->getEmail())) {
                throw new Exception("Email already exists,wait for authority approval or contact administrator");
            // header('Location: register_form.php');; // Or handle this case as needed
            }
    
            $sql = "INSERT INTO registration_table (fname, lname, email, gender, username, password,Role) "
                 . "VALUES (:fname, :lname,  :email, :gender, :username, :password,:Role)";
                $params = array(
                    'fname' => $user->getFirstname(),
                    'lname' => $user->getLastname(),
                    'email' => $user->getEmail(),
                    'gender' => $user->getGender(),
                    'username' => $user->getUsername(),
                    'password' => $user->getPassword(),
                    'Role' => $user->getRole(),
                );
            $stmt = $this->link->prepare($sql);
            $status = $stmt->execute($params);
            if ($status != true) {
                $errorInfo = $stmt->errorInfo();
                throw new Exception("Could not save user: " . $errorInfo[2]);
            }
    
            $id = $this->link->lastInsertId('registration_table');
    
            return $id;
        }


    public function getUserByUsername($username) {
        $sql = "SELECT * FROM registration_table WHERE username = :username";
        $params = array('username' => $username);
        $stmt = $this->link->prepare($sql);
        $status = $stmt->execute($params);
        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not retrieve user: " . $errorInfo[2]);
        }

        $user = null;
        if ($stmt->rowCount() == 1) {
            $row = $stmt->fetch();
            $id = $row['id'];
            $username = $row['username'];
            $pwd = $row['password'];
            $role = $row['Role'];
            $em = $row['email'];

            $gender = $row['gender'];
            $lastname = $row['lname'];
            $firstname = $row['fname'];
            

            $user = new User1($id, $username, $password, $email, $firstname, $lastname, $gender,$role);
        }
        return $user;
    }

    public function emailExists($email) {
        $sql = "SELECT COUNT(*) FROM registration_table WHERE email = :email";
        $stmt = $this->link->prepare($sql);
        $stmt->execute(['email' => $email]);
        $count = $stmt->fetchColumn();
        return ($count > 0);
    }




    
}

?>