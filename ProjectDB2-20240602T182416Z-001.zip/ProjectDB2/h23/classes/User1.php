<?php
class User1 {
    private $id;
    private $username;
    private $password;
    private $email;
    private $firstname;
    private $lastname;
    private $gender;
    private $role;

    public function __construct($i, $uname, $pwd, $em, $name, $lname, $g, $r) {
        $this->id = $i;
        $this->username = $uname;
        $this->password = $pwd;
        $this->email = $em;
        $this->firstname = $name;
        $this->lastname = $lname;
        $this->gender = $g;
        $this->role = $r;
    }

    // Getters and setters
    public function getId() { return $this->id; }
    public function getUsername() { return $this->username; }
    public function getPassword() { return $this->password; }
    public function getFirstname() {
        return $this->firstname;}

    public function getLastName() { return $this->lastname; }
    public function getGender() { return $this->gender; }
    public function getEmail() { return $this->email; }
    public function getRole() { return $this->role; }

    public function setId($i) { $this->id = $i; }
    public function setUsername($uname) { $this->username = $uname; }
    public function setPassword($pwd) { $this->password = $pwd; }

    public function setRole($r) { $this->role = $r; }

    public function setFirstname($name) {
        $this->firstname = $name;
    }
    public function setLastName($l) { $this->lastname = $l; }
    public function setGender($g) { $this->gender = $g; }
    public function setEmail($em) { $this->email = $em; }
}
?>
