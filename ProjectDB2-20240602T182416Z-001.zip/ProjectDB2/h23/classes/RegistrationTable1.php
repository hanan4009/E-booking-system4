<?php
require_once 'DB1.php';
require_once 'User1.php';

class RegistrationTable1
{
    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    public function insert(User1 $user)
    {
        $stmt = $this->connection->prepare("INSERT INTO registration_table (fname, lname, gender, email, username, password) VALUES (:fname, :lname, :gender, :email, :username, :password)");
        $stmt->bindValue(':fname', $user->getFname());
        $stmt->bindValue(':lname', $user->getLname());
        $stmt->bindValue(':gender', $user->getGender());
        $stmt->bindValue(':email', $user->getEmail());
        $stmt->bindValue(':username', $user->getUsername());
        $stmt->bindValue(':password', $user->getPassword());
        $stmt->execute();
        return $this->connection->lastInsertId();
    }
}
?>
