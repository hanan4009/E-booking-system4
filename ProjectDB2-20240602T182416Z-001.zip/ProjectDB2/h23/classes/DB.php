<?php
class DB {

    private static $host = "localhost";
    private static $database = "Home_Login";
    private static $username = "root";
    private static $password = "";
    
    public static function getConnection() {
        $dsn = 'mysql:host=' . DB::$host . ';dbname=' . DB::$database;

        $connection = new PDO($dsn, DB::$username, DB::$password);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


        // Add the following lines to set up the new PDO connection attributes
   //     $connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
   //     $connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        return $connection;
    }

}