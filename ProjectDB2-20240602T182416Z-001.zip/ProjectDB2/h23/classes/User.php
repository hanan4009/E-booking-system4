<?php
class User {
    private $id;
    private $username;
    private $password;
    private $role;
    private $email; // Add this lin

    public function __construct($i, $uname, $pwd, $r, $e){
        $this->id = $i;
        $this->username = $uname;
        $this->password = $pwd;
        $this->role = $r;
        $this->email = $e; // Set email property
        
    }
    public function getId() { return $this->id; }
    public function getUsername() { return $this->username; }
    public function getPassword() { return $this->password; }
    public function getRole() { return $this->role; }
    public function setEmail($e) { $this->email = $e; }

    public function setId($i) { $this->id = $i; }
    public function setUsername($n) { $this->username = $n; }
    public function setPassword($p) { $this->password = $p; }
    public function setRole($r) { $this->role = $r; }
    // Add getEmail and setEmail methods if needed
    public function getEmail() { return $this->email; }
}
?>