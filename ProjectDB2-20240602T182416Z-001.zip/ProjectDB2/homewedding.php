<!-- Masthead-->
<header class="masthead">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/swipebox.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/easy-responsive-tabs.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/chocolat.css">
    
</header>
<div id="portfolio">
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <?php 
            include 'admin/db_connect.php';
            $qry = $conn->query("SELECT * FROM room_categories where ctype like 'Wedding' order by rand()");
            while($row = $qry->fetch_assoc()):
            ?>
            <div class="col-lg-4 col-sm-6">
                <a class="portfolio-box" href="#">
                    <img class="img-fluid" src="assets/img/<?php echo $row['cover_img']; ?>" alt="">
                    <div class="portfolio-box-caption">
                        <div class="project-category text-white-30"><?php echo "$ ".number_format($row['price'], 2); ?> per day</div>
                        <div class="project-name"><?php echo $row['name']; ?></div>
                    </div>
                </a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>
